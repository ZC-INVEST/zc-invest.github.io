// /.netlify/functions/contact
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }
  try {
    const data = JSON.parse(event.body || '{}');
    // Basic validation
    if (!data.name || !data.email || !data.message || !data.date || !data.time) {
      return { statusCode: 400, body: JSON.stringify({ ok:false, error:'missing_fields' }) };
    }
    // TODO: route to email or CRM
    console.log('RDV Request:', data);
    return { statusCode: 200, body: JSON.stringify({ ok:true }) };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ ok:false, error:'server_error' }) };
  }
};
